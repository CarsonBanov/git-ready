# Future

* [x] include images for extension
* [x] local storage, cookies, etc. for preserving state of comment (expanded/collapsed)
* [x] probably want to do button on comments on the code not just "issuecomment"
* [x] re-loop after someone submits a comment to add new button (need to check if button exists)
* [x] publish so we don't have to install using dev mode
* [x] allow files to be collapsed on /files
* [x] can collapse inline comments
* [ ] expand all or collapse all button
* [ ] load script on all pages but only execute on github pull request pages rather than specifying PR regex in manifest (some links to PRs on github don't cause a page reload so the script isn't injected)
